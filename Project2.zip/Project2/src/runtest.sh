g++ main.cpp saleRep.cpp transaction.cpp territory.cpp transactionSystem.cpp fileParser.cpp -o test
./test territory.txt salerep.txt transaction.txt territory_out.txt