// Week5Assignment.h 
//



int add2Integer(std::istringstream * iss);

std::string output2Integer(int x, int y);

std::string output2IntegerLeftJustify(int x, int y);

double add2Double(std::istringstream * iss);

std::string output2Double(double x, double y);

int countLine(std::istringstream * iss);



